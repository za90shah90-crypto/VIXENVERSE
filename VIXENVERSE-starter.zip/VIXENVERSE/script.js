const translations = {
ar: {
navGames:"الألعاب",navDaily:"تحدّي اليوم",navAbout:"عن المشروع",eyebrow:"عالم مفتوح للجميع • تحديات بلا حدود",
heroTitle:'عالمك يبدأ<br><em>خلف هذا الباب.</em>',heroDesc:"ادخل عوالم الألغاز، اختبر سرعة بديهتك، واكتشف أي شخصية تسكن داخلك. كل جولة تخبّئ شيئًا جديدًا.",
explore:"اكتشف الألعاب",learnMore:"اكتشف الحكاية",statGames:"ألعاب جاهزة",statCuriosity:"فضول بلا نهاية",statCreator:"عقل خلف الفكرة",artCard1:"فكّر خارج المألوف",artCard2:"سرّ ينتظر اكتشافك",
dailyKicker:"ملفّ اليوم",dailyTitle:"هل يمكنك خداع المتاهة؟",dailyDesc:"حلّ لغزًا قصيرًا وافتح طريقك إلى الجولة التالية.",playNow:"العب الآن",
gamesKicker:"اختر بوابتك",gamesTitle:"أيّ عالم ستختبر؟",gamesDesc:"أربع بدايات، وعدد لا نهائي من الطرق لتثبت ذكاءك.",
tagPuzzle:"لغز ومنطق",tagSpeed:"سرعة بديهة",tagPersonality:"اختبار شخصية",tagParty:"تحدٍّ مضحك",difficultyMedium:"متوسط",difficultyFast:"سريع",difficultyChill:"على مهل",difficultyGroup:"مع الأصدقاء",
riddleName:"المتاهة التي تكذب",riddleDesc:"ثلاث بوابات، وثلاث عبارات، وحقيقة واحدة. اكتشف الطريق الصحيح.",speedName:"شرارة العقل",speedDesc:"لديك 20 ثانية. أجب عن أكبر عدد من الأسئلة قبل أن ينفد الوقت.",personalityName:"أثرُك في العالم المفقود",personalityDesc:"قراراتك في رحلة خيالية تكشف أيّ نمط من المستكشفين يشبهك.",chaosName:"كارثة تحت السيطرة",chaosDesc:"اسحب مهمة غريبة، نفّذها أو مثّلها، ودع المجموعة تحكم على النتيجة.",
enterGame:"ادخل اللعبة",quote:"ليست كل الأبواب تُفتح بالمفاتيح. بعضها يحتاج إلى فكرة لم تخطر لأحد.",quoteCredit:"— من قوانين VIXENVERSE",aboutKicker:"وراء البوابة",aboutTitle:"هذا العالم من صنع الخيال.",aboutDesc:"VIXENVERSE مشروع ألعاب مستقل، يتوسع مع كل فكرة جديدة. هنا تبدأ الألغاز، وتولد المنافسات، ولا تنتهي الحكاية عند شاشة النتيجة.",createdBy:"ابتكار وتطوير",footerLine:"عالم من الألعاب والألغاز",
modalRiddle:"المتاهة التي تكذب",modalSpeed:"شرارة العقل",modalPersonality:"أثرُك في العالم المفقود",modalChaos:"كارثة تحت السيطرة",
riddleIntro:"ثلاث بوابات أمامك. اقرأ العبارات: واحدة فقط من العبارات التالية صحيحة. اختر البوابة التي تقود إلى المخرج.",riddleQ:"أي بوابة تختار؟",riddleA:["البوابة القرمزية: «المخرج خلف البوابة الزرقاء»","البوابة الزرقاء: «المخرج ليس خلف هذه البوابة»","البوابة الفضية: «المخرج ليس خلف البوابة القرمزية»"],riddleCorrect:"أحسنت! اكتشفت أن المخرج خلف البوابة القرمزية. المنطق انتصر على الزخرفة.",riddleWrong:"ليس هذا هو الحل. تذكّر: عبارة واحدة فقط صحيحة. جرّب مجددًا.",
speedIntro:"أجب بسرعة. لديك 20 ثانية، وكل إجابة صحيحة تمنحك نقطة.",start:"ابدأ التحدي",timeLeft:"الوقت المتبقي",score:"النقاط",next:"السؤال التالي",finish:"انتهى التحدي!",speedDone:"نتيجتك",again:"العب مجددًا",
personalityIntro:"اختر ما يشبهك في كل موقف. لا توجد إجابة صحيحة أو خاطئة؛ هذه رحلة خيالية للتسلية.",continue:"متابعة",personalityResult:"شخصيتك في العالم المفقود",explorer:"المستكشف الهادئ",explorerDesc:"تراقب التفاصيل قبل التحرك. فضولك يقودك إلى أبواب لا يلاحظها الآخرون.",strategist:"العقل المدبّر",strategistDesc:"تحب ربط الأدلة ووضع خطة. بالنسبة إليك، كل لغز ينتظر أن يُفكّك.",spark:"شرارة الفوضى",sparkDesc:"تتبع حدسك وتحوّل المواقف الغريبة إلى مغامرة لا تُنسى.",guardian:"حارس الفريق",guardianDesc:"تفكر في المجموعة وتبحث عن حل يتيح للجميع الوصول إلى النهاية.",
chaosIntro:"اسحب بطاقة مهمة، اقرأها للمجموعة، ثم حاول تنفيذها أو تمثيلها خلال 30 ثانية. لا تصوير أو إحراج مطلوب؛ المتعة أهم.",drawTask:"اسحب مهمة",anotherTask:"مهمة أخرى",taskLabel:"مهمتك",taskDone:"أنجزتم المهمة؟ امنحوا أنفسكم نقطة ضحك.",close:"إغلاق",playAgain:"إعادة اللعب",
tasks:["اشرح كيف تصنع شطيرة كما لو كنت عالمًا يعلن اكتشافًا خطيرًا.","مثّل روبوتًا يحاول فهم معنى كلمة «إجازة».","اختر شيئًا قريبًا وأقنع المجموعة أنه أداة أثرية من عام 3026.","اخترع إعلانًا مدته 10 ثوانٍ لمنتج لا يحتاجه أحد.","صف يومك باستخدام ثلاثة أصوات فقط، من دون كلمات.","مثّل مذيع أخبار يعلن أن البطاطس أصبحت رئيسة الكوكب.","اخترع اسمًا ووظيفة لمخلوق خيالي يعيش داخل الوسادة.","تحدث لمدة 15 ثانية كأنك شرير يشرح خطته لفعل شيء لطيف.","اجعل المجموعة تخمّن فيلمًا خياليًا اخترعته الآن.","اخترع قانونًا غريبًا لمدينة خيالية وفسّر لماذا هو مهم."],
speedQuestions:[{q:"كم ضلعًا للمثلث؟",a:["2","3","4"],c:1},{q:"ما الكوكب المعروف بالكوكب الأحمر؟",a:["الزهرة","المريخ","زحل"],c:1},{q:"ما ناتج 8 × 7؟",a:["54","56","64"],c:1},{q:"أيّها ليس من الفصول الأربعة؟",a:["الخريف","الضباب","الربيع"],c:1},{q:"كم دقيقة في ساعتين؟",a:["100","120","140"],c:1},{q:"ما عكس كلمة «غامض»؟",a:["واضح","بعيد","قديم"],c:0},{q:"أيّ حيوان يُعرف بملك الغابة في التعبير الشائع؟",a:["النمر","الأسد","الثعلب"],c:1},{q:"ما العدد الأولي؟",a:["9","11","15"],c:1},{q:"ما ناتج 15 + 27؟",a:["32","42","52"],c:1},{q:"أيّ حاسة نستخدمها لسماع الأصوات؟",a:["البصر","السمع","اللمس"],c:1}],
};
translations.en = {
navGames:"Games",navDaily:"Daily challenge",navAbout:"About",eyebrow:"OPEN TO EVERYONE • LIMITLESS CHALLENGES",
heroTitle:'Your world begins<br><em>behind this door.</em>',heroDesc:"Enter puzzle worlds, test your quick thinking, and discover which character lives within you. Every round hides something new.",
explore:"Explore games",learnMore:"Discover the story",statGames:"Ready-to-play games",statCuriosity:"Endless curiosity",statCreator:"One mind behind it",artCard1:"Think beyond the usual",artCard2:"A secret awaits",
dailyKicker:"TODAY'S FILE",dailyTitle:"Can you outsmart the maze?",dailyDesc:"Solve a short riddle and unlock your way to the next round.",playNow:"Play now",
gamesKicker:"CHOOSE YOUR PORTAL",gamesTitle:"Which world will you test?",gamesDesc:"Four beginnings, endless ways to prove your wit.",
tagPuzzle:"PUZZLE & LOGIC",tagSpeed:"QUICK THINKING",tagPersonality:"PERSONALITY",tagParty:"FUN CHALLENGE",difficultyMedium:"Medium",difficultyFast:"Fast",difficultyChill:"Relaxed",difficultyGroup:"With friends",
riddleName:"The Lying Maze",riddleDesc:"Three gates, three statements, one truth. Find the right path.",speedName:"Mind Spark",speedDesc:"You have 20 seconds. Answer as many questions as you can.",personalityName:"Your Trace in the Lost World",personalityDesc:"Choices on a fantasy journey reveal your explorer type.",chaosName:"Controlled Chaos",chaosDesc:"Draw a strange task, perform it or act it out, and let the group judge.",
enterGame:"Enter game",quote:"Not every door opens with a key. Some need an idea no one has thought of.",quoteCredit:"— From the laws of VIXENVERSE",aboutKicker:"BEHIND THE PORTAL",aboutTitle:"This world is made of imagination.",aboutDesc:"VIXENVERSE is an independent games project that grows with every new idea. Puzzles begin here, rivalries are born, and the story doesn't end at the results screen.",createdBy:"Created & developed by",footerLine:"A world of games and mysteries",
modalRiddle:"The Lying Maze",modalSpeed:"Mind Spark",modalPersonality:"Your Trace in the Lost World",modalChaos:"Controlled Chaos",
riddleIntro:"Three gates stand before you. Only one of these statements is true. Choose the gate that leads to the exit.",riddleQ:"Which gate do you choose?",riddleA:["Crimson gate: “The exit is behind the blue gate.”","Blue gate: “The exit is not behind this gate.”","Silver gate: “The exit is not behind the crimson gate.”"],riddleCorrect:"Well done! The exit is behind the crimson gate. Logic beats decoration.",riddleWrong:"Not quite. Remember: only one statement is true. Try again.",
speedIntro:"Answer quickly. You have 20 seconds, and every correct answer earns a point.",start:"Start challenge",timeLeft:"Time left",score:"Score",next:"Next question",finish:"Challenge complete!",speedDone:"Your score",again:"Play again",
personalityIntro:"Choose what feels most like you in each situation. No right or wrong answers; this is a fun fictional journey.",continue:"Continue",personalityResult:"Your character in the lost world",explorer:"The Quiet Explorer",explorerDesc:"You notice details before moving. Your curiosity leads you to doors others miss.",strategist:"The Strategist",strategistDesc:"You connect clues and make plans. Every puzzle is a system waiting to be solved.",spark:"The Chaos Spark",sparkDesc:"You follow your instincts and turn strange moments into unforgettable adventures.",guardian:"The Team Guardian",guardianDesc:"You think about the group and look for a solution that helps everyone reach the end.",
chaosIntro:"Draw a task card, read it to the group, then perform or act it out in 30 seconds. No filming or embarrassment needed; fun comes first.",drawTask:"Draw a task",anotherTask:"Another task",taskLabel:"Your task",taskDone:"Did you complete it? Give yourselves a laugh point.",close:"Close",playAgain:"Play again",
tasks:["Explain how to make a sandwich as if announcing a dangerous scientific discovery.","Act like a robot trying to understand the meaning of “vacation.”","Pick a nearby object and convince the group it's an artifact from 3026.","Create a 10-second ad for a product nobody needs.","Describe your day using only three sound effects, no words.","Act as a news anchor announcing that potatoes are now president of the planet.","Invent a name and job for a fantasy creature that lives inside a pillow.","Speak for 15 seconds like a villain explaining a plan to do something nice.","Make the group guess a fantasy movie you just invented.","Invent a strange law for a fictional city and explain why it matters."],
speedQuestions:[{q:"How many sides does a triangle have?",a:["2","3","4"],c:1},{q:"Which planet is known as the Red Planet?",a:["Venus","Mars","Saturn"],c:1},{q:"What is 8 × 7?",a:["54","56","64"],c:1},{q:"Which is not one of the four seasons?",a:["Autumn","Fog","Spring"],c:1},{q:"How many minutes are in two hours?",a:["100","120","140"],c:1},{q:"What is the opposite of “mysterious”?",a:["Clear","Distant","Ancient"],c:0},{q:"Which animal is commonly called the king of the jungle?",a:["Tiger","Lion","Fox"],c:1},{q:"Which is a prime number?",a:["9","11","15"],c:1},{q:"What is 15 + 27?",a:["32","42","52"],c:1},{q:"Which sense lets us hear sounds?",a:["Sight","Hearing","Touch"],c:1}]
};

const personalityQuestions = {
 ar:[
  {q:"في ممرّ مظلم، وجدت بابًا يهمس باسمك. ماذا تفعل؟",a:[["أفحص الرموز حوله أولًا","explorer"],["أبحث عن نمط أو آلية لفتحه","strategist"],["أفتحه فورًا بدافع الفضول","spark"],["أتأكد أن الفريق مستعد للدخول","guardian"]]},
  {q:"وجدت خريطة ناقصة ورفيقك قلق. كيف تتصرف؟",a:[["أبحث عن علامات صغيرة في الورقة","explorer"],["أعيد رسم الخريطة من الأدلة","strategist"],["أختار طريقًا غير متوقع","spark"],["أقسم الأدوار وأجمع آراء الجميع","guardian"]]},
  {q:"حصلت على أداة سحرية واحدة. أيّها تختار؟",a:[["عدسة تكشف الأشياء المخفية","explorer"],["ساعة تعيد آخر دقيقة","strategist"],["مفتاح يفتح بابًا عشوائيًا","spark"],["درع يحمي شخصًا آخر","guardian"]]}
 ],
 en:[
  {q:"In a dark corridor, a door whispers your name. What do you do?",a:[["Inspect the symbols around it first","explorer"],["Look for a pattern or mechanism","strategist"],["Open it immediately out of curiosity","spark"],["Make sure the team is ready","guardian"]]},
  {q:"You find an incomplete map and your companion is worried. What now?",a:[["Look for tiny marks on the paper","explorer"],["Rebuild the map from clues","strategist"],["Choose an unexpected route","spark"],["Divide tasks and hear everyone out","guardian"]]},
  {q:"You can keep one magical tool. Which do you choose?",a:[["A lens that reveals hidden things","explorer"],["A clock that rewinds one minute","strategist"],["A key that opens a random door","spark"],["A shield that protects someone else","guardian"]]}
 ]
};
let lang = "ar", speedTimer = null, speedRemaining = 20, speedIndex = 0, speedScore = 0, personalityIndex = 0, personalityScores = {}, taskLast = -1;
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
function t(key){return translations[lang][key] ?? translations.ar[key] ?? key}
function setLanguage(next){
 lang=next; document.documentElement.lang=lang; document.documentElement.dir=lang==="ar"?"rtl":"ltr";
 document.body.dir=lang==="ar"?"rtl":"ltr";
 $$("[data-i18n]").forEach(el=>{const k=el.dataset.i18n; if(translations[lang][k])el.innerHTML=translations[lang][k]});
 $("#languageToggle").textContent=lang==="ar"?"EN ↗":"عربي ↗";
}
$("#languageToggle").addEventListener("click",()=>setLanguage(lang==="ar"?"en":"ar"));
function openModal(id){
 clearInterval(speedTimer); $("#gameFeedback").textContent=""; $("#gameBody").innerHTML="";
 const titles={riddle:"modalRiddle",speed:"modalSpeed",personality:"modalPersonality",chaos:"modalChaos"};
 $("#modalTitle").textContent=t(titles[id]); $("#modalCategory").textContent=id.toUpperCase();
 $("#gameModal").classList.remove("hidden");
 if(id==="riddle") renderRiddle(); if(id==="speed") renderSpeedIntro(); if(id==="personality") renderPersonality(); if(id==="chaos") renderChaosIntro();
}
function closeModal(){clearInterval(speedTimer);$("#gameModal").classList.add("hidden")}
$$("[data-launch]").forEach(b=>b.addEventListener("click",()=>openModal(b.dataset.launch)));
$$("[data-close]").forEach(b=>b.addEventListener("click",closeModal));
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});

function renderRiddle(){
 const choices=t("riddleA");
 $("#gameBody").innerHTML=`<p>${t("riddleIntro")}</p><p><strong>${t("riddleQ")}</strong></p><div class="option-list">${choices.map((c,i)=>`<button class="game-option" data-riddle="${i}">${c}</button>`).join("")}</div>`;
 $$("[data-riddle]").forEach(b=>b.addEventListener("click",()=>{
  const chosen=Number(b.dataset.riddle);
  // Puzzle's only consistent answer is crimson: if exit is crimson, statement 1 false, statement 2 true, statement 3 false. Thus only one statement is true.
  $$("[data-riddle]").forEach(x=>x.disabled=true);
  if(chosen===0){b.classList.add("correct");$("#gameFeedback").textContent=t("riddleCorrect");}
  else {b.classList.add("wrong");$("#gameFeedback").textContent=t("riddleWrong"); const retry=document.createElement("button");retry.className="primary-small";retry.textContent=t("again");retry.onclick=renderRiddle;$("#gameFeedback").append(" ",retry);}
 }));
}
function renderSpeedIntro(){
 $("#gameBody").innerHTML=`<p>${t("speedIntro")}</p><button class="primary-small" id="startSpeed">${t("start")}</button>`;
 $("#startSpeed").onclick=startSpeed;
}
function startSpeed(){
 clearInterval(speedTimer);speedRemaining=20;speedIndex=0;speedScore=0;showSpeedQuestion();
 speedTimer=setInterval(()=>{speedRemaining--;const el=$("#timer");if(el)el.textContent=speedRemaining;if(speedRemaining<=0)endSpeed()},1000);
}
function showSpeedQuestion(){
 const qs=t("speedQuestions");if(speedIndex>=qs.length){endSpeed();return}
 const q=qs[speedIndex];
 $("#gameBody").innerHTML=`<div class="timer-row"><span>${t("timeLeft")}: <strong id="timer">${speedRemaining}</strong>s</span><span>${t("score")}: <strong>${speedScore}</strong></span></div><div class="progress-line"><span style="width:${(speedIndex/qs.length)*100}%"></span></div><p><strong>${q.q}</strong></p><div class="option-list">${q.a.map((a,i)=>`<button class="game-option" data-speed="${i}">${a}</button>`).join("")}</div>`;
 $$("[data-speed]").forEach(b=>b.addEventListener("click",()=>{if(b.disabled)return;$$("[data-speed]").forEach(x=>x.disabled=true);if(Number(b.dataset.speed)===q.c){speedScore++;b.classList.add("correct")}else{b.classList.add("wrong");$$("[data-speed]").find(x=>Number(x.dataset.speed)===q.c)?.classList.add("correct")}speedIndex++;setTimeout(()=>{if(speedRemaining>0)showSpeedQuestion()},450)}));
}
function endSpeed(){clearInterval(speedTimer);$("#gameBody").innerHTML=`<div class="result-box"><span>${t("finish")}</span><br><strong>${speedScore} / ${t("speedQuestions").length}</strong><p>${t("speedDone")}</p></div><button class="primary-small" id="restartSpeed">${t("again")}</button>`;$("#restartSpeed").onclick=renderSpeedIntro;$("#gameFeedback").textContent=""}
function renderPersonality(){
 personalityIndex=0;personalityScores={explorer:0,strategist:0,spark:0,guardian:0};showPersonalityQuestion();
}
function showPersonalityQuestion(){
 const qs=personalityQuestions[lang];if(personalityIndex>=qs.length){showPersonalityResult();return}
 const q=qs[personalityIndex];
 $("#gameBody").innerHTML=`<div class="progress-line"><span style="width:${(personalityIndex/qs.length)*100}%"></span></div><p>${q.q}</p><div class="option-list">${q.a.map((a,i)=>`<button class="game-option" data-personality="${i}">${a[0]}</button>`).join("")}</div>`;
 $$("[data-personality]").forEach(b=>b.addEventListener("click",()=>{const chosen=q.a[Number(b.dataset.personality)][1];personalityScores[chosen]++;personalityIndex++;showPersonalityQuestion()}));
}
function showPersonalityResult(){
 const max=Math.max(...Object.values(personalityScores));const winner=Object.keys(personalityScores).find(k=>personalityScores[k]===max)||"explorer";
 const names={explorer:"explorer",strategist:"strategist",spark:"spark",guardian:"guardian"};
 $("#gameBody").innerHTML=`<div class="result-box"><span>${t("personalityResult")}</span><br><strong>${t(names[winner])}</strong><p>${t(names[winner]+"Desc")}</p></div><button class="primary-small" id="restartPersonality">${t("playAgain")}</button>`;
 $("#restartPersonality").onclick=renderPersonality;
}
function renderChaosIntro(){
 $("#gameBody").innerHTML=`<p>${t("chaosIntro")}</p><button class="primary-small" id="drawTask">${t("drawTask")}</button><div id="taskResult"></div>`;
 $("#drawTask").onclick=drawTask;
}
function drawTask(){
 const tasks=t("tasks");let idx=Math.floor(Math.random()*tasks.length);if(tasks.length>1&&idx===taskLast)idx=(idx+1)%tasks.length;taskLast=idx;
 $("#taskResult").innerHTML=`<div class="result-box"><span>${t("taskLabel")}</span><p class="task-text">${tasks[idx]}</p><p>${t("taskDone")}</p></div><button class="primary-small" id="anotherTask">${t("anotherTask")}</button>`;
 $("#anotherTask").onclick=drawTask;$("#gameFeedback").textContent="";
}
setLanguage("ar");
